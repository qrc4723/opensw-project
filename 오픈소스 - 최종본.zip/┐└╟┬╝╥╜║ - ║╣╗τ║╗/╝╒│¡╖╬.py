while(1):
    print("손난로 가동중!!!")
