import pygame, sys
import bubble
import swordtycoon
import FindBomb
import jump
import blackjack_pygame

pygame.init()

small_font = pygame.font.SysFont('malgungothic', 20)
mark = pygame.image.load('mark.png')

class Button1:
    def __init__(self, text, width, height, pos):
        self.pressed = False
        # 버튼의 top 
        self.top_rect = pygame.Rect(pos, (width, height))
        self.top_color = '#475F77'
        # 버튼의 text
        self.text_surf = small_font.render(text, True, '#FFFFFF')
        self.text_rect = self.text_surf.get_rect(center = self.top_rect.center)

    def draw(self):
        pygame.draw.rect(screen, self.top_color, self.top_rect, border_radius = 10)
        screen.blit(self.text_surf, self.text_rect)
        self.check_click()
        
    def check_click(self):
        mouse_pos = pygame.mouse.get_pos()
        if self.top_rect.collidepoint(mouse_pos):
            if pygame.mouse.get_pressed()[0]:
                self.pressed = True
            else:
                if self.pressed == True:
                    bubble.main1()
                    print('click')
                    self.pressed = False
class Button2:
    def __init__(self, text, width, height, pos):
        self.pressed = False
        # 버튼의 top 
        self.top_rect = pygame.Rect(pos, (width, height))
        self.top_color = '#475F77'
        # 버튼의 text
        self.text_surf = small_font.render(text, True, '#FFFFFF')
        self.text_rect = self.text_surf.get_rect(center = self.top_rect.center)

    def draw(self):
        pygame.draw.rect(screen, self.top_color, self.top_rect, border_radius = 10)
        screen.blit(self.text_surf, self.text_rect)
        self.check_click()
        
    def check_click(self):
        mouse_pos = pygame.mouse.get_pos()
        if self.top_rect.collidepoint(mouse_pos):
            if pygame.mouse.get_pressed()[0]:
                self.pressed = True
            else:
                if self.pressed == True:
                    jump.rungame()
                    print('click')
                    self.pressed = False
                    
class Button3:
    def __init__(self, text, width, height, pos):
        self.pressed = False
        # 버튼의 top 
        self.top_rect = pygame.Rect(pos, (width, height))
        self.top_color = '#475F77'
        # 버튼의 text
        self.text_surf = small_font.render(text, True, '#FFFFFF')
        self.text_rect = self.text_surf.get_rect(center = self.top_rect.center)

    def draw(self):
        pygame.draw.rect(screen, self.top_color, self.top_rect, border_radius = 10)
        screen.blit(self.text_surf, self.text_rect)
        self.check_click()
        
    def check_click(self):
        mouse_pos = pygame.mouse.get_pos()
        if self.top_rect.collidepoint(mouse_pos):
            if pygame.mouse.get_pressed()[0]:
                self.pressed = True
            else:
                if self.pressed == True:
                    FindBomb.main_menu()
                    print('click')
                    self.pressed = False
                    
class Button4:
    def __init__(self, text, width, height, pos):
        self.pressed = False
        # 버튼의 top 
        self.top_rect = pygame.Rect(pos, (width, height))
        self.top_color = '#475F77'
        # 버튼의 text
        self.text_surf = small_font.render(text, True, '#FFFFFF')
        self.text_rect = self.text_surf.get_rect(center = self.top_rect.center)

    def draw(self):
        pygame.draw.rect(screen, self.top_color, self.top_rect, border_radius = 10)
        screen.blit(self.text_surf, self.text_rect)
        self.check_click()
        
    def check_click(self):
        mouse_pos = pygame.mouse.get_pos()
        if self.top_rect.collidepoint(mouse_pos):
            if pygame.mouse.get_pressed()[0]:
                self.pressed = True
            else:
                if self.pressed == True:
                    swordtycoon.runGame()
                    print('click')
                    self.pressed = False       
                                
class Button5:
    def __init__(self, text, width, height, pos):
        self.pressed = False
        # 버튼의 top 
        self.top_rect = pygame.Rect(pos, (width, height))
        self.top_color = '#475F77'
        # 버튼의 text
        self.text_surf = small_font.render(text, True, '#FFFFFF')
        self.text_rect = self.text_surf.get_rect(center = self.top_rect.center)

    def draw(self):
        pygame.draw.rect(screen, self.top_color, self.top_rect, border_radius = 10)
        screen.blit(self.text_surf, self.text_rect)
        self.check_click()
        
    def check_click(self):
        mouse_pos = pygame.mouse.get_pos()
        if self.top_rect.collidepoint(mouse_pos):
            if pygame.mouse.get_pressed()[0]:
                self.pressed = True
            else:
                if self.pressed == True: 
                    blackjack_pygame.rungame()
                    print('click')
                    self.pressed = False  
                    
screen = pygame.display.set_mode((500, 500))
pygame.display.set_caption('GUI MENU')
clock = pygame.time.Clock()

def runGame():
    screen = pygame.display.set_mode((800, 600))
    
    button1 = Button1('물방울 피하기', 200, 40, (300, 50))
    button2 = Button2('장애물 피하기', 200, 40, (50, 230))
    button3 = Button3('지뢰 찾기', 200, 40, (550, 230))
    button4 = Button4('검키우기', 200, 40, (150, 450))
    button5 = Button5('블랙잭', 200, 40, (450, 450))

    while True:
        event = pygame.event.poll() #이벤트 처리
        screen.fill((255, 255, 255))
        screen.blit(mark, (300, 200))
        button1.draw()
        button2.draw()
        button3.draw()
        button4.draw()
        button5.draw()
        if event.type == pygame.QUIT:
            exit()
        pygame.display.update() #모든 화면 그리기 업데이트
        clock.tick(60)  
            
runGame()
pygame.quit()