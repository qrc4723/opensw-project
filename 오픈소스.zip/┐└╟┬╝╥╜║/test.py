import random

class huddle:
    xy = [0,0]
    way = True
    type = ''
    def __init__(self, type, way, xy):
        self.xy = xy
        self.way = way
        self.type = type
        
    def __del__(self):
        pass
    def check(self):
        if self.xy[0] > 1525 or self.xy[0] < 0 or self.xy[1] > 800 or self.xy[0] < 0:
            del self
    def random_point(self):
        self.type = random.randint(0,1)
        self.way = random.randint(0,1)
        self.xy = [self.way * 1500,random.randint(480,560)]

a = huddle
a.random_point(a)
print(a.xy)
a.random_point(a)
print(a.xy)
